﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshFilter))]

public class WaterTightMesh : MonoBehaviour
{
    private Mesh mesh;

    private Vector3[] verticies;
    private int[] triangles;

    private void Awake()
    {
        mesh = GetComponent<MeshFilter>().mesh;
    }

    // Start is called before the first frame update
    void Start()
    {
        MakeMeshData();
        CreateMesh();
    }

    // Update is called once per frame
    void Update()
    {

    }

    void MakeMeshData()
    {
        verticies = new Vector3[] { new Vector3(0, 0, 0), new Vector3(0, 0, 1), new Vector3(1, 0, 0),
                                    new Vector3(1, 0, 0), new Vector3(0, 0, 1), new Vector3(1, 0, 1),
                                    new Vector3(1, 0, 1), new Vector3(0, 0, 1), new Vector3(0, 1, 1),
                                    new Vector3(0, 1, 1), new Vector3(1, 1, 1), new Vector3(1, 0, 1),
                                    new Vector3(1, 0, 1), new Vector3(1, 0, 0), new Vector3(1, 1, 0),
                                    new Vector3(1, 1, 0), new Vector3(1, 1, 1), new Vector3(1, 0, 1),
                                    new Vector3(0, 0, 0), new Vector3(1, 0, 0), new Vector3(1, 1, 0),
                                    new Vector3(1, 1, 0), new Vector3(0, 1, 0), new Vector3(0, 0, 0),
                                    new Vector3(0, 0, 0), new Vector3(0, 0, 1), new Vector3(0, 1, 0),
                                    new Vector3(0, 1, 0), new Vector3(0, 0, 1), new Vector3(0, 1, 1),
                                    new Vector3(0, 1, 1), new Vector3(0, 1, 0), new Vector3(1, 1, 1),
                                    new Vector3(1, 1, 1), new Vector3(0, 1, 0), new Vector3(1, 1, 0)};

        triangles = new int[] { 5, 4, 3, 2, 1, 0,
                                11, 10, 9, 8, 7, 6,
                                12, 13, 14, 15, 16, 17,
                                23, 22, 21, 20, 19, 18,
                                24, 25, 26, 27, 28, 29,
                                35, 34, 33, 32, 31, 30};
    }

    void CreateMesh()
    {
        mesh.Clear();
        mesh.vertices = verticies;
        mesh.triangles = triangles;

        mesh.RecalculateNormals();
    }
}